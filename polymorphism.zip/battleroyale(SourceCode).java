// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <polymorphism>
package projectpolymorphism;

//imports
import project3.characters.Abstract;
import project3.characters.Superheroes;
import project3.characters.Villian;
import project3.characters.Sidekick;
import java.util.Random;

//Write a driver class that simulates a Battle Royale between the characters in the array.
public class battleroyale {

   // use this so we know how many people/characters will be living 
   public static int numAlive(Abstract[] people) {
       //make sure to start off at 0
	   int number = 0;
       //array of several (at least 4) game characters of different types loop
	   int starts;
       for(starts=0;starts<people.length;starts++){
           //need to go by 1 when the character is living
    	   if(people[starts].isAlive())
        	   number++;
       }
       return number;
   }
  
   public static void main(String[] args) {

       //Create an array of several (at least 4) game characters of different types.
       Abstract[] people = new Abstract[4];
       people[0] = new Superheroes("Batman");
       people[1] = new Villian("Joker");
       people[2] = new Sidekick("Robin");
       people[3] = new Villian("Bane");
      
       //select an attacker at random from the array
       Random value = new Random();
       //killer, person trying to kill
       int killer;
       //defender, person trying to live
       int defender; 
      
       //making sure you can see all the people/characters when the fight starts
       System.out.println("START OF FIGHT BETWEEN EVERYBODY!!!!!!!!");
       System.out.println();
       int begins;
       for(begins=0;begins<people.length;begins++) {
           System.out.println(people[begins]);
           System.out.println();
       }
       System.out.println();
      
       //In a loop, select an attacker at random from the array and have them attack a random character/person.
       while(numAlive(people) > 1){
    	   //select an attacker at random from the array
           killer = value.nextInt(people.length); 
           //Continue until only one character/person remains.
           while(!people[killer].isAlive()) {
               killer = value.nextInt(people.length);
           }
          
           //select another attacker at random from the array
           defender = value.nextInt(people.length);
           //Continue until only one character/person remains. (know which person is living and not)
           while((!people[defender].isAlive()) || (killer == defender)){
               defender = value.nextInt(people.length);
           }
          
           // printing out to show who was trying to kill and who was trying to defend
           System.out.println(people[killer].getCharactersname()+" "+"is trying to kill"+" "+people[defender].getCharactersname());
           //when person is trying to kill defender
           people[defender].hit(people[killer].attack());
           // showing number of life health points each person has
           System.out.println(people[defender].getCharactersname()+" "+"life health points is"+" "+people[defender].getTotalnumberhealth());
           System.out.println();
       }
      
       //making sure you can see all the people/characters when the fight ends
       System.out.println("THE FIGHT IS NOW FINISHED!!!!!!!!!!!");
       System.out.println();
       int finished;
       for(finished=0;finished<people.length;finished++){
           System.out.println(people[finished]);
           System.out.println();
       }
      
      //Print out the name of the winner.
       int winner;
       for(winner=0;winner<people.length;winner++){
           if(people[winner].isAlive()){
        	   System.out.println();
               System.out.println(people[winner].getCharactersname()+" "+"IS VICTORIUOS!!!!!!!!!");
               break;
           }
       }     
   }
}


